﻿namespace Demo
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.m_wndPorts = new System.Windows.Forms.ComboBox();
			this.m_wndRatus = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.m_wndDataBit = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.m_wndStopBit = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.m_wndCheckBit = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.m_wndStartButton = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label6 = new System.Windows.Forms.Label();
			this.m_wndSourceText = new System.Windows.Forms.TextBox();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.m_wndMessageObject = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(34, 35);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(53, 12);
			this.label1.TabIndex = 0;
			this.label1.Text = "串口号：";
			// 
			// m_wndPorts
			// 
			this.m_wndPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.m_wndPorts.FormattingEnabled = true;
			this.m_wndPorts.Location = new System.Drawing.Point(86, 32);
			this.m_wndPorts.Name = "m_wndPorts";
			this.m_wndPorts.Size = new System.Drawing.Size(109, 20);
			this.m_wndPorts.TabIndex = 1;
			// 
			// m_wndRatus
			// 
			this.m_wndRatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.m_wndRatus.FormattingEnabled = true;
			this.m_wndRatus.Location = new System.Drawing.Point(269, 32);
			this.m_wndRatus.Name = "m_wndRatus";
			this.m_wndRatus.Size = new System.Drawing.Size(114, 20);
			this.m_wndRatus.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(222, 35);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(53, 12);
			this.label2.TabIndex = 2;
			this.label2.Text = "波特率：";
			// 
			// m_wndDataBit
			// 
			this.m_wndDataBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.m_wndDataBit.FormattingEnabled = true;
			this.m_wndDataBit.Location = new System.Drawing.Point(456, 32);
			this.m_wndDataBit.Name = "m_wndDataBit";
			this.m_wndDataBit.Size = new System.Drawing.Size(81, 20);
			this.m_wndDataBit.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(407, 35);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(53, 12);
			this.label3.TabIndex = 4;
			this.label3.Text = "数据位：";
			// 
			// m_wndStopBit
			// 
			this.m_wndStopBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.m_wndStopBit.FormattingEnabled = true;
			this.m_wndStopBit.Location = new System.Drawing.Point(602, 32);
			this.m_wndStopBit.Name = "m_wndStopBit";
			this.m_wndStopBit.Size = new System.Drawing.Size(81, 20);
			this.m_wndStopBit.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(555, 35);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(53, 12);
			this.label4.TabIndex = 6;
			this.label4.Text = "停止位：";
			// 
			// m_wndCheckBit
			// 
			this.m_wndCheckBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.m_wndCheckBit.FormattingEnabled = true;
			this.m_wndCheckBit.Location = new System.Drawing.Point(752, 32);
			this.m_wndCheckBit.Name = "m_wndCheckBit";
			this.m_wndCheckBit.Size = new System.Drawing.Size(81, 20);
			this.m_wndCheckBit.TabIndex = 9;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(705, 35);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(53, 12);
			this.label5.TabIndex = 8;
			this.label5.Text = "校验位：";
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.m_wndStartButton);
			this.groupBox1.Controls.Add(this.m_wndPorts);
			this.groupBox1.Controls.Add(this.m_wndCheckBit);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.m_wndRatus);
			this.groupBox1.Controls.Add(this.m_wndStopBit);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.m_wndDataBit);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(23, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(964, 80);
			this.groupBox1.TabIndex = 10;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "串口配置";
			// 
			// m_wndStartButton
			// 
			this.m_wndStartButton.Location = new System.Drawing.Point(857, 27);
			this.m_wndStartButton.Name = "m_wndStartButton";
			this.m_wndStartButton.Size = new System.Drawing.Size(87, 28);
			this.m_wndStartButton.TabIndex = 11;
			this.m_wndStartButton.Text = "开始";
			this.m_wndStartButton.UseVisualStyleBackColor = true;
			this.m_wndStartButton.Click += new System.EventHandler(this.m_wndStartButton_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.Controls.Add(this.splitContainer1);
			this.groupBox2.Location = new System.Drawing.Point(23, 107);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(964, 425);
			this.groupBox2.TabIndex = 12;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "接收数据";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(12, 13);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(53, 12);
			this.label6.TabIndex = 0;
			this.label6.Text = "源数据：";
			// 
			// m_wndSourceText
			// 
			this.m_wndSourceText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.m_wndSourceText.Location = new System.Drawing.Point(14, 28);
			this.m_wndSourceText.Multiline = true;
			this.m_wndSourceText.Name = "m_wndSourceText";
			this.m_wndSourceText.ReadOnly = true;
			this.m_wndSourceText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.m_wndSourceText.Size = new System.Drawing.Size(468, 374);
			this.m_wndSourceText.TabIndex = 1;
			this.m_wndSourceText.WordWrap = false;
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(3, 17);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.m_wndSourceText);
			this.splitContainer1.Panel1.Controls.Add(this.label6);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.m_wndMessageObject);
			this.splitContainer1.Panel2.Controls.Add(this.label7);
			this.splitContainer1.Size = new System.Drawing.Size(958, 405);
			this.splitContainer1.SplitterDistance = 487;
			this.splitContainer1.TabIndex = 2;
			// 
			// m_wndMessageObject
			// 
			this.m_wndMessageObject.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.m_wndMessageObject.Location = new System.Drawing.Point(9, 28);
			this.m_wndMessageObject.Multiline = true;
			this.m_wndMessageObject.Name = "m_wndMessageObject";
			this.m_wndMessageObject.ReadOnly = true;
			this.m_wndMessageObject.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.m_wndMessageObject.Size = new System.Drawing.Size(455, 374);
			this.m_wndMessageObject.TabIndex = 3;
			this.m_wndMessageObject.WordWrap = false;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(7, 13);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(65, 12);
			this.label7.TabIndex = 2;
			this.label7.Text = "解析数据：";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1004, 544);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "MainForm";
			this.Text = "NMEA Parse DEMO";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox m_wndPorts;
		private System.Windows.Forms.ComboBox m_wndRatus;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox m_wndDataBit;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox m_wndStopBit;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox m_wndCheckBit;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button m_wndStartButton;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.TextBox m_wndSourceText;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox m_wndMessageObject;
		private System.Windows.Forms.Label label7;
	}
}

