namespace Blaney
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.m_azimuth = new System.Windows.Forms.TextBox();
			this.m_elevation = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.Elevation = new System.Windows.Forms.Label();
			this.zoomin_button = new System.Windows.Forms.Button();
			this.zoomout_button = new System.Windows.Forms.Button();
			this.rate_text = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.m_point1_latitude = new System.Windows.Forms.TextBox();
			this.m_point1_longitude = new System.Windows.Forms.TextBox();
			this.m_point2_latitude = new System.Windows.Forms.TextBox();
			this.m_point2_longitude = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.m_calculate_btn = new System.Windows.Forms.Button();
			this.m_distance_text = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(12, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(566, 480);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// m_azimuth
			// 
			this.m_azimuth.Location = new System.Drawing.Point(646, 15);
			this.m_azimuth.Name = "m_azimuth";
			this.m_azimuth.Size = new System.Drawing.Size(100, 20);
			this.m_azimuth.TabIndex = 1;
			// 
			// m_elevation
			// 
			this.m_elevation.Location = new System.Drawing.Point(646, 58);
			this.m_elevation.Name = "m_elevation";
			this.m_elevation.Size = new System.Drawing.Size(100, 20);
			this.m_elevation.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(584, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(44, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Azimuth";
			// 
			// Elevation
			// 
			this.Elevation.AutoSize = true;
			this.Elevation.Location = new System.Drawing.Point(584, 65);
			this.Elevation.Name = "Elevation";
			this.Elevation.Size = new System.Drawing.Size(51, 13);
			this.Elevation.TabIndex = 4;
			this.Elevation.Text = "Elevation";
			// 
			// zoomin_button
			// 
			this.zoomin_button.Location = new System.Drawing.Point(670, 128);
			this.zoomin_button.Name = "zoomin_button";
			this.zoomin_button.Size = new System.Drawing.Size(75, 23);
			this.zoomin_button.TabIndex = 5;
			this.zoomin_button.Text = "Zoom In";
			this.zoomin_button.UseVisualStyleBackColor = true;
			this.zoomin_button.Click += new System.EventHandler(this.ZoomInHandler);
			// 
			// zoomout_button
			// 
			this.zoomout_button.Location = new System.Drawing.Point(670, 157);
			this.zoomout_button.Name = "zoomout_button";
			this.zoomout_button.Size = new System.Drawing.Size(75, 23);
			this.zoomout_button.TabIndex = 6;
			this.zoomout_button.Text = "Zoom Out";
			this.zoomout_button.UseVisualStyleBackColor = true;
			this.zoomout_button.Click += new System.EventHandler(this.ZoomOutHandler);
			// 
			// rate_text
			// 
			this.rate_text.Enabled = false;
			this.rate_text.Location = new System.Drawing.Point(670, 187);
			this.rate_text.Name = "rate_text";
			this.rate_text.Size = new System.Drawing.Size(76, 20);
			this.rate_text.TabIndex = 7;
			this.rate_text.Text = "1";
			this.rate_text.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(633, 190);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(30, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Rate";
			// 
			// m_point1_latitude
			// 
			this.m_point1_latitude.Location = new System.Drawing.Point(680, 253);
			this.m_point1_latitude.Name = "m_point1_latitude";
			this.m_point1_latitude.Size = new System.Drawing.Size(100, 20);
			this.m_point1_latitude.TabIndex = 9;
			// 
			// m_point1_longitude
			// 
			this.m_point1_longitude.Location = new System.Drawing.Point(680, 280);
			this.m_point1_longitude.Name = "m_point1_longitude";
			this.m_point1_longitude.Size = new System.Drawing.Size(100, 20);
			this.m_point1_longitude.TabIndex = 10;
			// 
			// m_point2_latitude
			// 
			this.m_point2_latitude.Location = new System.Drawing.Point(680, 321);
			this.m_point2_latitude.Name = "m_point2_latitude";
			this.m_point2_latitude.Size = new System.Drawing.Size(100, 20);
			this.m_point2_latitude.TabIndex = 11;
			// 
			// m_point2_longitude
			// 
			this.m_point2_longitude.Location = new System.Drawing.Point(680, 348);
			this.m_point2_longitude.Name = "m_point2_longitude";
			this.m_point2_longitude.Size = new System.Drawing.Size(100, 20);
			this.m_point2_longitude.TabIndex = 12;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(584, 256);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(81, 13);
			this.label3.TabIndex = 13;
			this.label3.Text = "Point 1 Latitude";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(584, 287);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(90, 13);
			this.label4.TabIndex = 14;
			this.label4.Text = "Point 1 Longitude";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(584, 321);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(81, 13);
			this.label5.TabIndex = 15;
			this.label5.Text = "Point 2 Latitude";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(584, 351);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(90, 13);
			this.label6.TabIndex = 16;
			this.label6.Text = "Point 2 Longitude";
			// 
			// m_calculate_btn
			// 
			this.m_calculate_btn.Location = new System.Drawing.Point(704, 375);
			this.m_calculate_btn.Name = "m_calculate_btn";
			this.m_calculate_btn.Size = new System.Drawing.Size(75, 23);
			this.m_calculate_btn.TabIndex = 17;
			this.m_calculate_btn.Text = "Calculate";
			this.m_calculate_btn.UseVisualStyleBackColor = true;
			this.m_calculate_btn.Click += new System.EventHandler(this.CalculateDistance);
			// 
			// m_distance_text
			// 
			this.m_distance_text.Enabled = false;
			this.m_distance_text.Location = new System.Drawing.Point(679, 414);
			this.m_distance_text.Name = "m_distance_text";
			this.m_distance_text.Size = new System.Drawing.Size(100, 20);
			this.m_distance_text.TabIndex = 18;
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(867, 508);
			this.Controls.Add(this.m_distance_text);
			this.Controls.Add(this.m_calculate_btn);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.m_point2_longitude);
			this.Controls.Add(this.m_point2_latitude);
			this.Controls.Add(this.m_point1_longitude);
			this.Controls.Add(this.m_point1_latitude);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.rate_text);
			this.Controls.Add(this.zoomout_button);
			this.Controls.Add(this.zoomin_button);
			this.Controls.Add(this.Elevation);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.m_elevation);
			this.Controls.Add(this.m_azimuth);
			this.Controls.Add(this.pictureBox1);
			this.Name = "frmMain";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.frmMain_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TextBox m_azimuth;
		private System.Windows.Forms.TextBox m_elevation;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label Elevation;
		private System.Windows.Forms.Button zoomin_button;
		private System.Windows.Forms.Button zoomout_button;
		private System.Windows.Forms.TextBox rate_text;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox m_point1_latitude;
		private System.Windows.Forms.TextBox m_point1_longitude;
		private System.Windows.Forms.TextBox m_point2_latitude;
		private System.Windows.Forms.TextBox m_point2_longitude;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button m_calculate_btn;
		private System.Windows.Forms.TextBox m_distance_text;
    }
}

