using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Ben
{
	public class ArpaRadarItem : RadarItem
	{
		int _id;
		int _azimuth;
		int _elevation;
		int _width;
		int _height;
		float _x = float.MinValue;
		float _y = float.MinValue;
		int _rotate;
        int _linearLength;
		DateTime _created = DateTime.Now;
		GraphicsPath _gp;

		public int ID
		{
			get
			{
				return _id;
			}
		}
		public int Azimuth
		{
			get
			{
				return _azimuth;
			}
			set
			{
				_azimuth = value;
				while (_azimuth < 0)
				{
					_azimuth += 360;
				}
				if (_azimuth >= 360)
					_azimuth = _azimuth % 360;
			}
		}

		public float X
		{
			get { return _x; }
			set { _x = value; }
		}

		public float Y
		{
			get { return _y; }
			set { _y = value; }
		}

		public int Elevation
		{
			get
			{
				return _elevation;
			}
			set
			{
				_elevation = value;
				if (_elevation > 90)
					_elevation = 90;
				else if (_elevation < 0)
					_elevation = 0;
			}
		}
		public int Height
		{
			get
			{
				return _height;
			}
			set
			{
			}
		}
		public int Width
		{
			get
			{
				return _width;
			}
			set
			{
			}
		}
		public DateTime Created
		{
			get
			{
				return _created;
			}
		}

		public ArpaRadarItem(int id, int size, int az, int el)
		{
			_id = id;
			_width = size;
			_height = size;
			_azimuth = az;
			_elevation = el;
		}

        public ArpaRadarItem(int id, int width, int height, float x, float y, int linearLength,int rotate = 90)
		{
			_id = id;
			_width = width;
			_height = height;
			_x = x;
			_y = y;
            _rotate = rotate;
            _linearLength = linearLength;
		}

		public void DrawItem(Radar radar, Graphics g)
		{
			PointF cp;

			if (_x != float.MinValue && _y != float.MinValue)
			{
				cp = new PointF((float) _x, (float) _y);
			}
			else
			{
				cp = radar.AzEl2XY(_azimuth, _elevation);
			}

            PointF _topLeft = new PointF(cp.X - ((float)_width / 2), cp.Y - ((float)_height / 2));

            //g.FillEllipse(new SolidBrush(Color.Blue), new RectangleF(new PointF(cp.X - ((float)5 / 2), cp.Y - ((float)5 / 2)), new SizeF((float)5, (float)5)));

			_gp = new GraphicsPath(FillMode.Winding);
            _gp.AddEllipse(new RectangleF(new PointF(cp.X - ((float)5 / 2), cp.Y - ((float)5 / 2)), new SizeF((float)5, (float)5)));
            g.FillPath(new SolidBrush(Color.Blue), _gp);
            _gp.AddEllipse(_topLeft.X, _topLeft.Y, _width, _width);
            //_gp.AddEllipse(_topLeft.X, _topLeft.Y, _width, 3);
            Random rnd = new Random();
            int rndLength = rnd.Next(30, 100);
            _gp.AddLine(cp, new PointF(cp.X, cp.Y - _linearLength));
            g.DrawPath(Pens.Blue, _gp);
            g.RotateTransform(_rotate);
            

            //if (_rotate != 90)
            //{
            //    Matrix translateMatrix = new Matrix();
            //    translateMatrix.Rotate(30);
            //    _gp.AddLine(p1, new PointF(p1.X, p1.Y - 30));
            //    _gp.Transform(translateMatrix);
            //    g.DrawPath(Pens.DarkTurquoise, _gp);
            //}
		}

		public int CompareTo(RadarItem item)
		{
			return 0;
		}
	}
}
