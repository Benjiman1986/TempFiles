using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Ben
{
	public class AisRadarItem : RadarItem
	{
		int _id;
		int _azimuth;
		int _elevation;
		int _width;
		int _height;
		float _x = float.MinValue;
		float _y = float.MinValue;
		int _range;
		float _rate;
		int _linearLength;
		GraphicsPath _gp;
		private DateTime _created;

		public int ID
		{
			get
			{
				return _id;
			}
		}
		public int Azimuth
		{
			get
			{
				return _azimuth;
			}
			set
			{
				_azimuth = value;
				while (_azimuth < 0)
				{
					_azimuth += 360;
				}
				if (_azimuth >= 360)
					_azimuth = _azimuth % 360;
			}
		}

		public float X
		{
			get { return _x; }
			set { _x = value / _rate; }
		}

		public float Y
		{
			get { return _y; }
			set { _y = value / _rate; }
		}

		public float Rate
		{
			get { return _rate; }
			set { _rate = value; }
		}

		public int Elevation
		{
			get
			{
				return _elevation;
			}
			set
			{
				_elevation = value;
				if (_elevation > 90)
					_elevation = 90;
				else if (_elevation < 0)
					_elevation = 0;
			}
		}
		public int Height
		{
			get
			{
				return _height;
			}
			set
			{
			}
		}
		public int Width
		{
			get
			{
				return _width;
			}
			set
			{
			}
		}
		public DateTime Created
		{
			get
			{
				return _created;
			}
		}

		public AisRadarItem(int id, int size, int az, int el)
		{
			_id = id;
			_width = size;
			_height = size;
			_azimuth = az;
			_elevation = el;
		}

		public AisRadarItem(int id, int width, int height, float x, float y, int range, int linearLength, float rate = 1F)
		{
			_id = id;
			_width = width;
			_height = height;
			_x = x / rate;
			_y = y / rate;
			_rate = rate;
			_range = 90 - range;
			_linearLength = linearLength;
		}

		public void DrawItem(Radar radar, Graphics g)
		{
			PointF cp;

			if (_x != float.MinValue && _y != float.MinValue)
			{
				cp = new PointF((float) _x, (float) _y);
			}
			else
			{
				cp = radar.AzEl2XY(_azimuth, _elevation);
			}

			PointF _topLeft = new PointF(cp.X - ((float)_width / 2), cp.Y - ((float)_height / 2));

			PointF p1 = new PointF(((float)_topLeft.X + ((float)_width / 2F)), (float)_topLeft.Y);
			PointF p2 = new PointF((float)_topLeft.X, (float)_topLeft.Y + (float)_height);
			PointF p3 = new PointF((float)_topLeft.X + (float)_width, (float)_topLeft.Y + (float)_height);

			_gp = new GraphicsPath(FillMode.Winding);
			_gp.AddPolygon(new PointF[] { p1, p2, p3 });

			_gp.AddLine(p1, new PointF(p1.X, p1.Y - _linearLength));
			g.ResetTransform();
			g.TranslateTransform(cp.X, cp.Y);
			g.RotateTransform(_range);
			g.TranslateTransform(-cp.X, -cp.Y);
			g.DrawPath(Pens.DarkTurquoise, _gp);
		}

		public int CompareTo(RadarItem item)
		{
			return 0;
		}
	}
}
