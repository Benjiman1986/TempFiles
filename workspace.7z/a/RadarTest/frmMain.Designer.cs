namespace Blaney
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.m_azimuth = new System.Windows.Forms.TextBox();
			this.m_elevation = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.Elevation = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(12, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(566, 480);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// m_azimuth
			// 
			this.m_azimuth.Location = new System.Drawing.Point(646, 84);
			this.m_azimuth.Name = "m_azimuth";
			this.m_azimuth.Size = new System.Drawing.Size(100, 20);
			this.m_azimuth.TabIndex = 1;
			// 
			// m_elevation
			// 
			this.m_elevation.Location = new System.Drawing.Point(646, 127);
			this.m_elevation.Name = "m_elevation";
			this.m_elevation.Size = new System.Drawing.Size(100, 20);
			this.m_elevation.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(584, 90);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(44, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Azimuth";
			// 
			// Elevation
			// 
			this.Elevation.AutoSize = true;
			this.Elevation.Location = new System.Drawing.Point(584, 134);
			this.Elevation.Name = "Elevation";
			this.Elevation.Size = new System.Drawing.Size(51, 13);
			this.Elevation.TabIndex = 4;
			this.Elevation.Text = "Elevation";
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(867, 508);
			this.Controls.Add(this.Elevation);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.m_elevation);
			this.Controls.Add(this.m_azimuth);
			this.Controls.Add(this.pictureBox1);
			this.Name = "frmMain";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.frmMain_Load);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.TextBox m_azimuth;
		private System.Windows.Forms.TextBox m_elevation;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label Elevation;
    }
}

