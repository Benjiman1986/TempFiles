using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Ben;

namespace Blaney
{
	public partial class frmMain : Form
	{
		Radar _radar;
		Timer t = new Timer();
		Random rnd = new Random();
		float currentRate = 1;

		public frmMain()
		{
			InitializeComponent();
			// internal item update timer
			t.Interval = 60;
			t.Tick += new EventHandler(t_Tick);
			t.Enabled = true;
			TroggleButtons();
		}

		//RadarItem item1 = new TriangleRadarItem(1, 8, 190, 60);
		//RadarItem item2 = new TriangleRadarItem(2, 8, 45, 45);
		RadarItem item1 = new ArpaRadarItem(1, 15, 15, 0, 0, 35, 30);
		RadarItem item2 = new AisRadarItem(2, 6, 18, 0, 0, 135, 30);
		RadarItem item3 = new AisRadarItem(3, 6, 18, 0, 0, 45, 50);

		int GetDelta()
		{
			int i = rnd.Next(0, 2);
			if (i == 0)
				i--;
			return i;
		}

		void t_Tick(object sender, EventArgs e)
		{
			// select which of the three items to update
			int i = rnd.Next(1, 4);

			switch (i)
			{
				case 3:
					item1.Rate = currentRate;
					float x, y;
					item1.X = !string.IsNullOrEmpty(m_azimuth.Text.Trim()) ? float.TryParse(m_azimuth.Text.Trim(), out x) ? x : 350 : 350;
					item1.Y = !string.IsNullOrEmpty(m_elevation.Text.Trim()) ? float.TryParse(m_elevation.Text.Trim(), out y) ? y : 190 : 190;
					_radar.AddItem(item1);
					item2.Rate = currentRate;
					item2.X = !string.IsNullOrEmpty(m_azimuth.Text.Trim()) ? float.TryParse(m_azimuth.Text.Trim(), out x) ? x : 200 : 200;
					item2.Y = !string.IsNullOrEmpty(m_elevation.Text.Trim()) ? float.TryParse(m_elevation.Text.Trim(), out y) ? y : 190 : 190;
					_radar.AddItem(item2);
					item3.Rate = currentRate;
					item3.X = !string.IsNullOrEmpty(m_azimuth.Text.Trim()) ? float.TryParse(m_azimuth.Text.Trim(), out x) ? x : 250 : 250;
					item3.Y = !string.IsNullOrEmpty(m_elevation.Text.Trim()) ? float.TryParse(m_elevation.Text.Trim(), out y) ? y : 90 : 90;
					_radar.AddItem(item3);
					break;
			}
		}

		private void frmMain_Load(object sender, EventArgs e)
		{
			_radar = new Radar(pictureBox1.Width, pictureBox1.Height);
			pictureBox1.Image = _radar.Image;
			_radar.ImageUpdate += new ImageUpdateHandler(_radar_ImageUpdate);
			_radar.DrawScanInterval = 60;
			//_radar.DrawScanLine = true;
			_radar.DrawScanLine = false;
		}

		void _radar_ImageUpdate(object sender, ImageUpdateEventArgs e)
		{
			// this event is important to catch!
			pictureBox1.Image = e.Image;
		}

		private void ZoomInHandler(object sender, EventArgs e)
		{
			currentRate -= 0.5f;
			this.rate_text.Text = currentRate.ToString();
			TroggleButtons();
		}

		private void ZoomOutHandler(object sender, EventArgs e)
		{
			currentRate += 0.5f;
			this.rate_text.Text = currentRate.ToString();
			TroggleButtons();
		}

		private void TroggleButtons()
		{
			if (currentRate <= 1)
			{
				this.zoomin_button.Enabled = false;
			}
			else
			{
				this.zoomin_button.Enabled = true;
			}
		}

		private void CalculateDistance(object sender, EventArgs e)
		{
			var distance = DistanceHelper.Distance(double.Parse(m_point1_latitude.Text),
				double.Parse(m_point1_longitude.Text), double.Parse(m_point2_latitude.Text),
				double.Parse(m_point2_longitude.Text));
			m_distance_text.Text = distance.ToString();
		}
	}
}