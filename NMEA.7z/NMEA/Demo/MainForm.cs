﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using NMEALite;

namespace Demo
{
	public partial class MainForm : Form
	{
		private PortReader m_PortReader;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			m_wndPorts.Items.AddRange(SerialPort.GetPortNames());
			m_wndRatus.Items.AddRange(new object[] { 2400, 4800, 9600, 19200, 38400 });
			m_wndDataBit.Items.AddRange(new object[] { 5, 6, 7, 8 });
			m_wndStopBit.Items.AddRange((object[])Enum.GetValues(typeof(StopBits)).Cast<object>().ToArray());
			m_wndCheckBit.Items.AddRange((object[])Enum.GetValues(typeof(Parity)).Cast<object>().ToArray());

			m_wndPorts.SelectedIndex = 0;
			m_wndRatus.SelectedIndex = 4;
			m_wndDataBit.SelectedIndex = 3;
			m_wndStopBit.SelectedIndex = 1;
			m_wndCheckBit.SelectedIndex = 0;
		}

		private void m_wndStartButton_Click(object sender, EventArgs e)
		{
			if (m_wndStartButton.Text == "停止")
			{
				if((m_PortReader != null) && (m_PortReader.IsOpen()))
				{
					m_PortReader.Close();
				}
			}
			else
			{
				if((m_PortReader != null) && (m_PortReader.IsOpen()))
				{
					m_PortReader.Close();
				}

				m_PortReader = new PortReader();
				m_PortReader.SourceTextReceivedEvent += M_PortReader_SourceTextReceivedEvent;
				m_PortReader.AisTelegrapheseReceivedEvent += M_PortReader_AisTelegrapheseReceivedEvent;
				m_PortReader.MessageReceivedEvent += M_PortReader_MessageReceivedEvent;

				var portName = m_wndPorts.SelectedItem.ToString();
				var ratus = Convert.ToInt32(m_wndRatus.SelectedItem);
				var dataBit = Convert.ToInt32(m_wndDataBit.SelectedItem);
				var stopBit = (StopBits)Enum.Parse(typeof(StopBits), m_wndStopBit.SelectedItem.ToString());
				var check = (Parity)Enum.Parse(typeof(Parity), m_wndCheckBit.SelectedItem.ToString());
				m_PortReader.OpenPort(portName, ratus, check, dataBit, stopBit);
			}

			m_wndPorts.Enabled = m_PortReader == null || !m_PortReader.IsOpen();
			m_wndRatus.Enabled = m_PortReader == null || !m_PortReader.IsOpen();
			m_wndDataBit.Enabled = m_PortReader == null || !m_PortReader.IsOpen();
			m_wndStopBit.Enabled = m_PortReader == null || !m_PortReader.IsOpen();
			m_wndCheckBit.Enabled = m_PortReader == null || !m_PortReader.IsOpen();

			m_wndStartButton.Text = (m_PortReader != null && m_PortReader.IsOpen()) ? "停止" : "开始";
		}

		private void M_PortReader_SourceTextReceivedEvent(string sourceText)
		{
			if (this.InvokeRequired)
			{
				var method = new SourceTextReceivedEventHandler(M_PortReader_SourceTextReceivedEvent);
				this.Invoke(method, new object[] { sourceText });
				return;
			}

			if(!string.IsNullOrWhiteSpace(sourceText))
			{
				m_wndSourceText.AppendText(sourceText.Trim() + "\r\n");
			}
		}

		private void AddObjectText(string objectText)
		{
			if (this.InvokeRequired)
			{
				var method = new AppendObjectTextHandler(AddObjectText);
				this.Invoke(method, new object[] { objectText });
				return;
			}

			if (!string.IsNullOrWhiteSpace(objectText))
			{
				m_wndMessageObject.AppendText(objectText + "\r\n\r\n\r\n");
			}
		}

		private void M_PortReader_MessageReceivedEvent(NMEAMessageBase telegraphese)
		{
			if (telegraphese != null)
			{
				switch (telegraphese.MessageType)
				{
					case NMEAMessageTypes.MessageTTM:
						{
							var tel = (NMEAMessageTTM)telegraphese;
							AddObjectText(DumpObjectValues(tel));
							break;
						}
					case NMEAMessageTypes.MessageTLL:
						{
							var tel = (NMEAMessageTLL)telegraphese;
							AddObjectText(DumpObjectValues(tel));
							break;
						}
					case NMEAMessageTypes.MessageTLB:
						{
							var tel = (NMEAMessageTLB)telegraphese;

							var txt = "NMEAMessageTLB";
							foreach ( var tlbItem in tel.TargetTableCollection)
							{
								txt += string.Format("{0}: {1}\r\n", tlbItem.Key, tlbItem.Value);
							}

							AddObjectText(txt);
							break;
						}
				}
			}
		}

		private void M_PortReader_AisTelegrapheseReceivedEvent(AisTelegrapheseBase telegraphese, AisTelegrapheseSourceTypes source)
		{
			if (telegraphese != null)
			{
				switch (telegraphese.TelegrapheseType)
				{
					case MessageTelegrapheseTypes.Telegraphese_1:
						{
							var tel = (AisTelegraphese_1)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_2:
						{
							var tel = (AisTelegraphese_2)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_3:
						{
							var tel = (AisTelegraphese_3)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_5:
						{
							var tel = (AisTelegraphese_5)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_18:
						{
							var tel = (AisTelegraphese_18)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_19:
						{
							var tel = (AisTelegraphese_19)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_24A:
						{
							var tel = (AisTelegraphese_24A)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
					case MessageTelegrapheseTypes.Telegraphese_24B:
						{
							var tel = (AisTelegraphese_24B)telegraphese;
							AddObjectText(string.Format("Source: {0}\r\n{1}", source, DumpObjectValues(tel)));
							break;
						}
				}
			}
			//throw new NotImplementedException();
		}

		private string DumpObjectValues(object obj)
		{
			string txt = "";
			foreach(PropertyDescriptor descriptor in TypeDescriptor.GetProperties(obj))
			{
				string name = descriptor.Name;
				object value = descriptor.GetValue(obj);
				txt += string.Format("{0} : {1}\r\n", name, value);
			}

			return txt.TrimEnd();
		}
	}

	public delegate void AppendObjectTextHandler(string text);
}
