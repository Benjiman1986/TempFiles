using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Blaney
{
    public partial class frmMain : Form
    {
        Radar _radar;
        Timer t = new Timer();
        Random rnd = new Random();

        public frmMain()
        {
            InitializeComponent();
            // internal item update timer
            t.Interval = 60;
            t.Tick += new EventHandler(t_Tick);
            t.Enabled = true;
        }

        RadarItem item1 = new SquareRadarItem(1, 8, 190, 60);
        RadarItem item2 = new CircleRadarItem(2, 8, 45, 45);
        RadarItem item3 = new TriangleRadarItem(3, 8, 30, 30);

        int GetDelta()
        {
            int i = rnd.Next(0, 2);
            if (i == 0)
                i--;
            return i;
        }

        void t_Tick(object sender, EventArgs e)
        {
            // select which of the three items to update
            int i = rnd.Next(1, 4);

            switch (i)
            {
                case 1:
                    item1.Azimuth += GetDelta();
                    item1.Elevation += GetDelta();
                    _radar.AddItem(item1);
                    break;
                case 2:
                    item2.Azimuth += GetDelta();
                    item2.Elevation += GetDelta();
                    _radar.AddItem(item2);
                    break;
                case 3:
                    item3.Azimuth += GetDelta();
                    item3.Elevation += GetDelta();
                    _radar.AddItem(item3);
                    break;
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            _radar = new Radar(pictureBox1.Width);
            pictureBox1.Image = _radar.Image;
            _radar.ImageUpdate += new ImageUpdateHandler(_radar_ImageUpdate);
            _radar.DrawScanInterval = 60;
            _radar.DrawScanLine = true;
        }

        void _radar_ImageUpdate(object sender, ImageUpdateEventArgs e)
        {
            // this event is important to catch!
            pictureBox1.Image = e.Image;
        }
    }
}